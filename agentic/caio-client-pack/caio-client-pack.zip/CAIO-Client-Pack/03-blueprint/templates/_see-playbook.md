The blueprint deliverables are the 10 `company-ai-os/` documents the architect produces — see PLAYBOOK.md.
